1.  Скопировать файл yandex-music.lua в папку \luaScr\user\video
2.  Скопировать файл rxijson.lua в папку \luaScr\lib
