1.  Скопировать файл sberzvuk.lua в папку \luaScr\user\video
2.  Скопировать файл rxijson.lua в папку \luaScr\lib
